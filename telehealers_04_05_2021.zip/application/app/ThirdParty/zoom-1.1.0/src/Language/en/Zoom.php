<?php

return [
    'invalidState'      => 'Invalid state.',
    'tokenExpired'        => 'The token has expired.'
];