<?php namespace Daycry\Zoom\Config;

use CodeIgniter\Config\BaseConfig;

class Zoom extends BaseConfig
{
    public $clientId = 'xxxxxxx';
    
    public $clientSecret = 'xxxxxxxx';

    public $redirectUrl = 'http://zoom.local/home/zoom/';
}