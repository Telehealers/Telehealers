<?php namespace Daycry\Zoom\Exceptions;

/**
 * @package Daycry\Zoom\\Exceptions
 */
interface ExceptionInterface {}