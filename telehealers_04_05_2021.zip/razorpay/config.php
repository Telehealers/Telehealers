<?php

//$keyId = 'rzp_test_pUfIiVm0hM4yBD';
//$keySecret = '4H3NF07V7a2RZhjqMJQhHGSK';

$keyId = 'rzp_test_PLSeO0PkhIlcII';
$keySecret = 'SCiN6HoUwvkeMI1uB5VNbkWT';
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
